<?php
function wptutsplus_register_theme_menu() {
    register_nav_menus(
    array(
        'primary'=>_ ('Main Navigation Menu' ),
        'secondry'=>_ ('Secondry Menu' ),
        'footernavmenu'=>('Footer Nav Menu')
    ));  
}
add_action( 'init', 'wptutsplus_register_theme_menu' );
?>


