<?php get_header(); ?>  
<section>
   <body class="fix-header>
        <div id="main-wrapper">
           
            <!-- End header header -->
            <div>
                <!-- Container fluid  -->
                <div class="container-fluid">
                    <!-- Start Page Content -->

                    <div class="row">
                        <!-- /# column -->
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-title">
                                    <h5>Enter URL Here</h5>
                                </div>
                                <form method="post" action="index.php">
                                    <div class="card-body">
                                        <div class="input-group input-group-rounded">
                                            <input type="text" placeholder="Start Crawl" name="target" class="form-control">
                                            <span class="input-group-btn"><button type="submit" class="btn btn-primary btn-group-right" name="crawl" value="Submit"><i class="fas fa-search"></i></button></span>
                                        </div>                                    
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-title">
                                    <h5>Tags </h5>

                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Keyword</th>
                                                    <th>Meta Description</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 <?php
                                                include_once('simple_html_dom.php');
                                                $html = new simple_html_dom();
                                                if (isset($_POST['crawl'])) {
                                                    $crawl = $_POST['target'];
                                                    $find = "https://";
                                                    if (strpos($crawl, $find) !== false) {
                                                        $html->load_file($crawl);
                                                        foreach ($html->find('title') as $title) {
                                                            foreach ($html->find('meta[name="keywords"]') as $keywords) {
                                                                foreach ($html->find('meta[property="og:description"]') as $description) {
                                                                    echo "</tr>";
                                                                    if ((strpos($title, "$crawl") !== false) || (strpos($keywords, "$crawl") !== false) || (strpos($description, "$crawl") !== false)) {
                                                                        echo "<td>";
                                                                        echo $title->plaintext;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $keywords->content;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $description->content;
                                                                        echo "</td>";
                                                                    } else if ((strpos($title, "http://") !== false) || (strpos($keywords, "https://") !== false) || (strpos($description, "https://") !== false)) {
                                                                        echo "<td>";
                                                                        echo $title->plaintext;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $keywords->content;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $description->content;
                                                                        echo "</td>";
                                                                    } else {
                                                                        echo "<td>";
                                                                        echo $title->plaintext;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $keywords->content;
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo $description->content;
                                                                        echo "</td>";
                                                                    }
                                                                    echo "</tr>";
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        echo '<div class="alert alert-warning alert-dismissable" id="flash-msg"><h4><i class="fas fa-exclamation-triangle"></i></i> Invalid URL! Enter HTTPS instead of HTTP...</h4></div>';
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card |<span class="badge badge-primary">Sale</span> | class="color-primary"-->
                        </div>
                        <!-- /# column -->

                        <!-- /# column -->
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-title">
                                    <h5>Crawled Urls </h5>

                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover ">
                                            <thead>
                                                <tr>
                                                    <th>Url</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                include_once('simple_html_dom.php');
                                                $html = new simple_html_dom();
                                                if (isset($_POST['crawl'])) {
                                                    $crawl = $_POST['target'];
                                                    $find = "https://";
                                                    if (strpos($crawl, $find) !== false) {
                                                        $html->load_file($crawl);
                                                        foreach ($html->find('a') as $link) {
                                                            echo "</tr>";
                                                            if (strpos($link, "$crawl") !== false) {
                                                                echo "<td>";
                                                                echo "<p class='links'>" . $link->href . "</p>";
                                                                echo "</td>";
                                                            } else if (strpos($link, "http://") !== false || strpos($link, "https://") !== false) {
                                                                echo "<td>";
                                                                echo "<p class='links'>" . $link->href . "</p>";
                                                                echo "</td>";
                                                            } else {
                                                                echo "<td>";
                                                                echo "<p class='links'>" . "$crawl/" . $link->href . "</p>";
                                                                echo "</td>";
                                                            }
                                                            echo "</tr>";
                                                        }
                                                    } else {
                                                        echo "Invalid URL!";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
		</div>
	
        <script>
            $(document).ready(function () {
                $("#flash-msg").delay(3000).fadeOut("slow");
            });
        </script>
	
</section>


<?php get_footer(); ?>